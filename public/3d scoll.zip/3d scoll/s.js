document.addEventListener("DOMContentLoaded", function () {
    let container, scene, camera, renderer, model, gui;

    function init() {
        container = document.querySelector(".scene.one");
        scene = new THREE.Scene();

        camera = new THREE.PerspectiveCamera(35, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.set(0, 1.2, 0.8);

        renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        container.appendChild(renderer.domElement);

        // Load Model
        const loader = new THREE.GLTFLoader();
        loader.load("game.glb", (gltf) => {
            model = gltf.scene;
            model.scale.set(1, 1, 1);
            model.rotation.set(0, 0, 0);
            model.position.set(0, 0, 0);
            scene.add(model);
            addGUI();  // Lil GUI Initialize
            animate();
            setTimeout(() => startAnimation(), 500);
        });
    }

    function animate() {
        requestAnimationFrame(animate);
        renderer.render(scene, camera);
    }

    function startAnimation() {
        gsap.timeline({
            scrollTrigger: {
                trigger: ".section-two",
                start: "top center",
                end: "bottom center",
                scrub: 4,
            },
        })
        .to(camera.position, { x: 0, y: 0.924, z: 0.308 })
        .to(model.position, { x: 0, y: 0.04, z: 0 })
        .to(model.rotation, { x: THREE.MathUtils.degToRad(12), y: 0, z: 0 });  // Rotation Fix
    }

    function addGUI() {
        gui = new lil.GUI();

        const modelFolder = gui.addFolder("Model Controls");
        modelFolder.add(model.position, "x", -2, 2).name("Position X");
        modelFolder.add(model.position, "y", -2, 2).name("Position Y");
        modelFolder.add(model.position, "z", -2, 2).name("Position Z");

        modelFolder.add(model.rotation, "x", -Math.PI / 2, Math.PI / 2).name("Rotate X");
        modelFolder.add(model.rotation, "y", -Math.PI / 2, Math.PI / 2).name("Rotate Y");
        modelFolder.add(model.rotation, "z", -Math.PI / 2, Math.PI / 2).name("Rotate Z");

        const cameraFolder = gui.addFolder("Camera Controls");
        cameraFolder.add(camera.position, "x", -3, 3).name("Camera X");
        cameraFolder.add(camera.position, "y", -3, 3).name("Camera Y");
        cameraFolder.add(camera.position, "z", -3, 8).name("Camera Z");

        modelFolder.open();
        cameraFolder.open();
    }

    init();
});
