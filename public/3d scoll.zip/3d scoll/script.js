document.addEventListener("DOMContentLoaded", function () {
    let container, scene, camera, renderer, model, controls, gui;

    function init() {
        container = document.querySelector(".scene.one");

        // Create Scene
        scene = new THREE.Scene();

        // Camera Setup
        const fov = 35;
        const aspect = window.innerWidth / window.innerHeight;
        const near = 0.1;
        const far = 1000;
        camera = new THREE.PerspectiveCamera(fov, aspect, near, far);
        camera.position.set(0, 1.2, 0.8);

        // Renderer
        renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(window.devicePixelRatio);
        container.appendChild(renderer.domElement);

        // HDRI Environment Setup
        const rgbeLoader = new THREE.RGBELoader();
        rgbeLoader.load("https://dl.polyhaven.org/file/ph-assets/HDRIs/hdr/1k/kiara_1_dawn_1k.hdr", function (texture) {
            texture.mapping = THREE.EquirectangularReflectionMapping;
            scene.environment = texture;  // Set environment map
        });

        // Load GLTF Model
        const loader = new THREE.GLTFLoader();
        loader.load(
            "game.glb", // Apne model ka path yahaan replace karein
            (gltf) => {
                model = gltf.scene;
                model.scale.set(1, 1, 1);
                model.rotation.set(0, 0, 0);
                model.position.set(0, 0, 0);
                scene.add(model);
                addGUI(); // GUI ko initialize karna
                animate();
            },
            (xhr) => {
                console.log(`Loading Model: ${(xhr.loaded / xhr.total) * 100}%`);
            },
            (error) => {
                console.error("Error loading model:", error);
            }
        );
    }

    function animate() {
        requestAnimationFrame(animate);
        renderer.render(scene, camera);
    }

    function addGUI() {
        gui = new lil.GUI();

        // Model Controls
        const modelFolder = gui.addFolder("Model Controls");
       // Model Position Controls
modelFolder.add(model.position, "x", -2, 2).name("Position X");
modelFolder.add(model.position, "y", -2, 2).name("Position Y");
modelFolder.add(model.position, "z", -2, 2).name("Position Z");

// Model Rotation Controls
modelFolder.add(model.rotation, "x", -Math.PI / 4, Math.PI / 4).name("Rotate X");
modelFolder.add(model.rotation, "y", -Math.PI / 4, Math.PI / 4).name("Rotate Y");
modelFolder.add(model.rotation, "z", -Math.PI / 4, Math.PI / 4).name("Rotate Z");

// Camera Position Controls
const cameraFolder = gui.addFolder("Camera Controls");
cameraFolder.add(camera.position, "x", -3, 3).name("Camera X");
cameraFolder.add(camera.position, "y", -3, 3).name("Camera Y");
cameraFolder.add(camera.position, "z", -3, 8).name("Camera Z"); // Z range thoda zyada rakha


        modelFolder.open();
        cameraFolder.open();
    }

    init();

    // Resize Handler
    window.addEventListener("resize", function () {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });

    // GSAP Animation
    gsap.registerPlugin(ScrollTrigger);

    let tl = gsap.timeline({
        scrollTrigger: {
            trigger: ".section-two",
            start: "top center",
            end: "bottom center",
            scrub: 4,
        },
    });

    tl.to(camera.position, { x: 0,y:0.924001,z:0.308002 })
      .to(model?.position, { x: 0,y:0.04,z:0 })
      .to(model?.rotation, { x: 0.204203522483337,y:0 ,z:0 })
    //   .to(model?.rotation, { z: 0.02, y: 3.1 }, "same")
    //   .to(camera.position, { x: 0.16 }, "same")
    //   .to(".scene.one", { opacity: 0, scale: 0 }, "same");
});


 